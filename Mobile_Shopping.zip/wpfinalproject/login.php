<?php
$user_name=$_POST['user_name'];
$password=$_POST['password'];
$conn=mysqli_connect('localhost','root','') or die(mysql_error());
mysqli_select_db($conn,'jar') or die(mysql_error());
$sql="select  * from table1 where username='$user_name' and password='$password'";
$result=mysqli_query($conn,$sql) ;
if(mysqli_num_rows($result)>0)
{
$row=mysqli_fetch_assoc($result);
echo $row["username"];
echo "\n";
echo "welcome";
}
else
echo "password does not match";?>
<HTML>

<HEAD>
<TITLE>I moved!!!</TITLE>
<META HTTP-EQUIV="refresh" CONTENT="10; demofirst.html">
</HEAD>

<BODY>

I moved to a new place.
Your browser should automatically take you there in 10 seconds. If it doesn't plase go to our homepage manually

</BODY>

</HTML>