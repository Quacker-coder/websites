<?php
$user_name=$_POST['user_name'];
$email=$_POST['email'];
$password=$_POST['password'];
echo "\n$user_name";
echo "\n$email";echo "\n$password";
$conn=mysqli_connect('localhost','root','') or die(mysql_error());
mysqli_select_db($conn,'jar')or die(mysql_error());
$sql="INSERT INTO table1 VALUES ('$user_name','$email','$password')";
mysqli_query($conn,$sql) ;	
?>